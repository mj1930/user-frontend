export const environment = {
  production: true,
  apiUrl: 'http://localhost:3001/',
  sellerUrl: 'http://localhost:3003/',
  adminApiUrl: 'http://localhost:3002/'
};
